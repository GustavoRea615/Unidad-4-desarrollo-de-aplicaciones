package boots.dao;

import org.springframework.data.repository.CrudRepository;

import boots.model.Provider;

public interface ProviderRepository extends CrudRepository<Provider, Integer>{

}
