package boots.dao;

import org.springframework.data.repository.CrudRepository;

import boots.model.Development;

public interface DevelopmentRepository extends CrudRepository<Development, Integer>{

}
