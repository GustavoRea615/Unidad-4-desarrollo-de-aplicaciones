package boots.dao;

import org.springframework.data.repository.CrudRepository;

import boots.model.Distributor;

public interface DistributorRepository extends CrudRepository<Distributor, Integer>{

}
