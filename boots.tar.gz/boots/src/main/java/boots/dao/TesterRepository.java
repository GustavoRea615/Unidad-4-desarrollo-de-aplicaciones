package boots.dao;

import org.springframework.data.repository.CrudRepository;

import boots.model.Tester;

public interface TesterRepository extends CrudRepository<Tester, Integer>{

}
