package boots.dao;

import org.springframework.data.repository.CrudRepository;

import boots.model.Desing;

public interface DesingRepository extends CrudRepository<Desing, Integer>{

}
